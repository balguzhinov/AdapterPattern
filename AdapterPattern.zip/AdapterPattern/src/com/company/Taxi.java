package com.company;

public interface Taxi {
    public void fill();
    public void drive();
}
