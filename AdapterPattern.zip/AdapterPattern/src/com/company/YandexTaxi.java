package com.company;

public class YandexTaxi {
    public void filling() {
        System.out.println("Yandex Taxi is filling the cars with petrol/gas");
    }

    public void driving() {
        System.out.println("Yandex Taxi is driving around the city/region");

    }
}
