package com.company;

public class AstanaTaxi {
    public void filling() {
        System.out.println("Astana Taxi filling the cars with petrol/gas");
    }

    public void driving() {
        System.out.println("Astana Taxi is driving around the city/region");

    }
}
