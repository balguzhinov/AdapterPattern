package com.company;
public class TaxiAdapter extends YandexTaxi implements Taxi {

    @Override
    public void fill() {
        filling();
    }

    @Override
    public void drive() {
        driving();
    }
}
